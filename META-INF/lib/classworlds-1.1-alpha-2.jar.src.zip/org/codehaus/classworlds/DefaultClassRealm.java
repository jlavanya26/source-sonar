/*     */ package org.codehaus.classworlds;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.TreeSet;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultClassRealm
/*     */   implements ClassRealm
/*     */ {
/*     */   private ClassWorld world;
/*     */   private String id;
/*     */   private TreeSet imports;
/*     */   private ClassLoader foreignClassLoader;
/*     */   private RealmClassLoader classLoader;
/*     */   private ClassRealm parent;
/*     */   
/*     */   public DefaultClassRealm(ClassWorld world, String id) {
/*  94 */     this(world, id, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultClassRealm(ClassWorld world, String id, ClassLoader foreignClassLoader) {
/*  99 */     this.world = world;
/*     */     
/* 101 */     this.id = id;
/*     */     
/* 103 */     this.imports = new TreeSet();
/*     */     
/* 105 */     if (foreignClassLoader != null)
/*     */     {
/* 107 */       this.foreignClassLoader = foreignClassLoader;
/*     */     }
/*     */     
/* 110 */     if ("true".equals(System.getProperty("classworlds.bootstrapped"))) {
/*     */       
/* 112 */       this.classLoader = new UberJarRealmClassLoader(this);
/*     */     }
/*     */     else {
/*     */       
/* 116 */       this.classLoader = new RealmClassLoader(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public URL[] getConstituents() {
/* 122 */     return this.classLoader.getURLs();
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassRealm getParent() {
/* 127 */     return this.parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParent(ClassRealm parent) {
/* 132 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId() {
/* 137 */     return this.id;
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassWorld getWorld() {
/* 142 */     return this.world;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void importFrom(String realmId, String packageName) throws NoSuchRealmException {
/* 148 */     this.imports.add(new Entry(getWorld().getRealm(realmId), packageName));
/* 149 */     this.imports.add(new Entry(getWorld().getRealm(realmId), packageName.replace('.', '/')));
/*     */   }
/*     */ 
/*     */   
/*     */   public void addConstituent(URL constituent) {
/* 154 */     this.classLoader.addConstituent(constituent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addConstituent(String constituent, byte[] b) throws ClassNotFoundException {
/*     */     try {
/*     */       File file;
/* 172 */       if (constituent.lastIndexOf('.') != -1) {
/*     */         
/* 174 */         File path = new File("byteclass/" + constituent.substring(0, constituent.lastIndexOf('.') + 1).replace('.', File.separatorChar));
/*     */         
/* 176 */         file = new File(path, constituent.substring(constituent.lastIndexOf('.') + 1) + ".class");
/*     */       }
/*     */       else {
/*     */         
/* 180 */         File path = new File("byteclass/");
/*     */         
/* 182 */         file = new File(path, constituent + ".class");
/*     */       } 
/*     */       
/* 185 */       addConstituent(new URL(null, file.toURL().toExternalForm(), new BytesURLStreamHandler(b)));
/*     */ 
/*     */     
/*     */     }
/* 189 */     catch (IOException e) {
/*     */       
/* 191 */       throw new ClassNotFoundException("Couldn't load byte stream.", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassRealm locateSourceRealm(String classname) {
/* 197 */     for (Iterator iterator = this.imports.iterator(); iterator.hasNext(); ) {
/*     */       
/* 199 */       Entry entry = iterator.next();
/*     */       
/* 201 */       if (entry.matches(classname))
/*     */       {
/* 203 */         return entry.getRealm();
/*     */       }
/*     */     } 
/*     */     
/* 207 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 212 */     return this.classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassRealm createChildRealm(String id) throws DuplicateRealmException {
/* 218 */     ClassRealm childRealm = getWorld().newRealm(id);
/*     */     
/* 220 */     childRealm.setParent(this);
/*     */     
/* 222 */     return childRealm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class loadClass(String name) throws ClassNotFoundException {
/* 232 */     if (name.startsWith("org.codehaus.classworlds."))
/*     */     {
/* 234 */       return getWorld().loadClass(name);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 239 */       if (this.foreignClassLoader != null) {
/*     */         
/*     */         try {
/*     */           
/* 243 */           return this.foreignClassLoader.loadClass(name);
/*     */         }
/* 245 */         catch (ClassNotFoundException e) {}
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 251 */       ClassRealm sourceRealm = locateSourceRealm(name);
/*     */       
/* 253 */       if (sourceRealm == this)
/*     */       {
/* 255 */         return this.classLoader.loadClassDirect(name);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 261 */         return sourceRealm.loadClass(name);
/*     */       }
/* 263 */       catch (ClassNotFoundException cnfe) {
/*     */ 
/*     */         
/* 266 */         return this.classLoader.loadClassDirect(name);
/*     */       }
/*     */     
/*     */     }
/* 270 */     catch (ClassNotFoundException e) {
/*     */       
/* 272 */       if (getParent() != null)
/*     */       {
/* 274 */         return getParent().loadClass(name);
/*     */       }
/*     */       
/* 277 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getResource(String name) {
/* 283 */     URL resource = null;
/* 284 */     name = UrlUtils.normalizeUrlPath(name);
/*     */     
/* 286 */     if (this.foreignClassLoader != null) {
/*     */       
/* 288 */       resource = this.foreignClassLoader.getResource(name);
/*     */       
/* 290 */       if (resource != null)
/*     */       {
/* 292 */         return resource;
/*     */       }
/*     */     } 
/*     */     
/* 296 */     ClassRealm sourceRealm = locateSourceRealm(name);
/*     */     
/* 298 */     if (sourceRealm == this) {
/*     */       
/* 300 */       resource = this.classLoader.getResourceDirect(name);
/*     */     }
/*     */     else {
/*     */       
/* 304 */       resource = sourceRealm.getResource(name);
/*     */       
/* 306 */       if (resource == null)
/*     */       {
/* 308 */         resource = this.classLoader.getResourceDirect(name);
/*     */       }
/*     */     } 
/*     */     
/* 312 */     if (resource == null && getParent() != null)
/*     */     {
/* 314 */       resource = getParent().getResource(name);
/*     */     }
/*     */     
/* 317 */     return resource;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getResourceAsStream(String name) {
/* 322 */     URL url = getResource(name);
/*     */     
/* 324 */     InputStream is = null;
/*     */     
/* 326 */     if (url != null) {
/*     */       
/*     */       try {
/*     */         
/* 330 */         is = url.openStream();
/*     */       }
/* 332 */       catch (IOException e) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 338 */     return is;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration findResources(String name) throws IOException {
/* 344 */     name = UrlUtils.normalizeUrlPath(name);
/*     */     
/* 346 */     Vector resources = new Vector();
/*     */ 
/*     */     
/* 349 */     if (this.foreignClassLoader != null)
/*     */     {
/* 351 */       for (Enumeration res = this.foreignClassLoader.getResources(name); res.hasMoreElements();)
/*     */       {
/* 353 */         resources.addElement(res.nextElement());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 358 */     ClassRealm sourceRealm = locateSourceRealm(name);
/*     */     
/* 360 */     if (sourceRealm != this)
/*     */     {
/*     */       
/* 363 */       for (Enumeration res = sourceRealm.findResources(name); res.hasMoreElements();)
/*     */       {
/* 365 */         resources.addElement(res.nextElement());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 370 */     for (Enumeration direct = this.classLoader.findResourcesDirect(name); direct.hasMoreElements();)
/*     */     {
/* 372 */       resources.addElement(direct.nextElement());
/*     */     }
/*     */ 
/*     */     
/* 376 */     if (this.parent != null)
/*     */     {
/* 378 */       for (Enumeration parent = getParent().findResources(name); parent.hasMoreElements();)
/*     */       {
/* 380 */         resources.addElement(parent.nextElement());
/*     */       }
/*     */     }
/*     */     
/* 384 */     return resources.elements();
/*     */   }
/*     */ 
/*     */   
/*     */   public void display() {
/* 389 */     ClassRealm cr = this;
/*     */     
/* 391 */     System.out.println("-----------------------------------------------------");
/*     */ 
/*     */     
/* 394 */     showUrls(cr);
/*     */     
/* 396 */     while (cr.getParent() != null) {
/*     */       
/* 398 */       System.out.println("\n");
/*     */       
/* 400 */       cr = cr.getParent();
/*     */       
/* 402 */       showUrls(cr);
/*     */     } 
/*     */     
/* 405 */     System.out.println("-----------------------------------------------------");
/*     */   }
/*     */ 
/*     */   
/*     */   private void showUrls(ClassRealm classRealm) {
/* 410 */     System.out.println("this realm = " + classRealm.getId());
/*     */     
/* 412 */     URL[] urls = classRealm.getConstituents();
/*     */     
/* 414 */     for (int j = 0; j < urls.length; j++)
/*     */     {
/* 416 */       System.out.println("urls[" + j + "] = " + urls[j]);
/*     */     }
/*     */     
/* 419 */     System.out.println("Number of imports: " + this.imports.size());
/*     */     
/* 421 */     for (Iterator i = this.imports.iterator(); i.hasNext();)
/*     */     {
/* 423 */       System.out.println("import: " + i.next());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworlds\DefaultClassRealm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */