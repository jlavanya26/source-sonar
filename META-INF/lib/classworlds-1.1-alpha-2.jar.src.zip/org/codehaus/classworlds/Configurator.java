/*     */ package org.codehaus.classworlds;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Configurator
/*     */ {
/*     */   public static final String MAIN_PREFIX = "main is";
/*     */   public static final String SET_PREFIX = "set";
/*     */   public static final String IMPORT_PREFIX = "import";
/*     */   public static final String LOAD_PREFIX = "load";
/*     */   public static final String OPTIONALLY_PREFIX = "optionally";
/*     */   private Launcher launcher;
/*     */   private ClassWorld world;
/*     */   private Map configuredRealms;
/*     */   
/*     */   public Configurator(Launcher launcher) {
/* 102 */     this.launcher = launcher;
/*     */     
/* 104 */     this.configuredRealms = new HashMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Configurator(ClassWorld world) {
/* 113 */     setClassWorld(world);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassWorld(ClassWorld world) {
/* 123 */     this.world = world;
/*     */     
/* 125 */     this.configuredRealms = new HashMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(InputStream is) throws IOException, MalformedURLException, ConfigurationException, DuplicateRealmException, NoSuchRealmException {
/* 142 */     BufferedReader reader = new BufferedReader(new InputStreamReader(is));
/*     */     
/* 144 */     if (this.world == null)
/*     */     {
/* 146 */       this.world = new ClassWorld();
/*     */     }
/*     */     
/* 149 */     ClassLoader foreignClassLoader = null;
/*     */     
/* 151 */     if (this.launcher != null) foreignClassLoader = this.launcher.getSystemClassLoader();
/*     */     
/* 153 */     ClassRealm curRealm = null;
/*     */     
/* 155 */     String line = null;
/*     */     
/* 157 */     int lineNo = 0;
/*     */     
/* 159 */     boolean mainSet = false;
/*     */ 
/*     */     
/*     */     while (true) {
/* 163 */       line = reader.readLine();
/*     */       
/* 165 */       if (line == null) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/* 170 */       lineNo++;
/* 171 */       line = line.trim();
/*     */       
/* 173 */       if (canIgnore(line)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 178 */       if (line.startsWith("main is")) {
/*     */         
/* 180 */         if (mainSet)
/*     */         {
/* 182 */           throw new ConfigurationException("Duplicate main configuration", lineNo, line);
/*     */         }
/*     */         
/* 185 */         String conf = line.substring("main is".length()).trim();
/*     */         
/* 187 */         int fromLoc = conf.indexOf("from");
/*     */         
/* 189 */         if (fromLoc < 0)
/*     */         {
/* 191 */           throw new ConfigurationException("Missing from clause", lineNo, line);
/*     */         }
/*     */         
/* 194 */         String mainClassName = conf.substring(0, fromLoc).trim();
/*     */         
/* 196 */         String mainRealmName = conf.substring(fromLoc + 4).trim();
/*     */         
/* 198 */         if (this.launcher != null)
/*     */         {
/* 200 */           this.launcher.setAppMain(mainClassName, mainRealmName);
/*     */         }
/*     */         
/* 203 */         mainSet = true; continue;
/*     */       } 
/* 205 */       if (line.startsWith("set")) {
/*     */         
/* 207 */         String conf = line.substring("set".length()).trim();
/*     */         
/* 209 */         int usingLoc = conf.indexOf(" using") + 1;
/*     */         
/* 211 */         String property = null;
/* 212 */         String propertiesFileName = null;
/* 213 */         if (usingLoc > 0) {
/*     */           
/* 215 */           property = conf.substring(0, usingLoc).trim();
/*     */           
/* 217 */           propertiesFileName = filter(conf.substring(usingLoc + 5).trim());
/*     */           
/* 219 */           conf = propertiesFileName;
/*     */         } 
/*     */         
/* 222 */         String defaultValue = null;
/*     */         
/* 224 */         int defaultLoc = conf.indexOf(" default") + 1;
/*     */         
/* 226 */         if (defaultLoc > 0) {
/*     */           
/* 228 */           defaultValue = conf.substring(defaultLoc + 7).trim();
/*     */           
/* 230 */           if (property == null) {
/*     */             
/* 232 */             property = conf.substring(0, defaultLoc).trim();
/*     */           }
/*     */           else {
/*     */             
/* 236 */             propertiesFileName = conf.substring(0, defaultLoc).trim();
/*     */           } 
/*     */         } 
/*     */         
/* 240 */         String value = System.getProperty(property);
/*     */         
/* 242 */         if (value != null) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 247 */         if (propertiesFileName != null) {
/*     */           
/* 249 */           File propertiesFile = new File(propertiesFileName);
/*     */           
/* 251 */           if (propertiesFile.exists()) {
/*     */             
/* 253 */             Properties properties = new Properties();
/*     */ 
/*     */             
/*     */             try {
/* 257 */               properties.load(new FileInputStream(propertiesFileName));
/*     */               
/* 259 */               value = properties.getProperty(property);
/*     */             }
/* 261 */             catch (Exception e) {}
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 268 */         if (value == null && defaultValue != null)
/*     */         {
/* 270 */           value = defaultValue;
/*     */         }
/*     */         
/* 273 */         if (value != null) {
/*     */           
/* 275 */           value = filter(value);
/* 276 */           System.setProperty(property, value);
/*     */         }  continue;
/*     */       } 
/* 279 */       if (line.startsWith("[")) {
/*     */         
/* 281 */         int rbrack = line.indexOf("]");
/*     */         
/* 283 */         if (rbrack < 0)
/*     */         {
/* 285 */           throw new ConfigurationException("Invalid realm specifier", lineNo, line);
/*     */         }
/*     */         
/* 288 */         String realmName = line.substring(1, rbrack);
/*     */         
/* 290 */         curRealm = this.world.newRealm(realmName, foreignClassLoader);
/*     */ 
/*     */         
/* 293 */         this.configuredRealms.put(realmName, curRealm); continue;
/*     */       } 
/* 295 */       if (line.startsWith("import")) {
/*     */         
/* 297 */         if (curRealm == null)
/*     */         {
/* 299 */           throw new ConfigurationException("Unhandled import", lineNo, line);
/*     */         }
/*     */         
/* 302 */         String conf = line.substring("import".length()).trim();
/*     */         
/* 304 */         int fromLoc = conf.indexOf("from");
/*     */         
/* 306 */         if (fromLoc < 0)
/*     */         {
/* 308 */           throw new ConfigurationException("Missing from clause", lineNo, line);
/*     */         }
/*     */         
/* 311 */         String importSpec = conf.substring(0, fromLoc).trim();
/*     */         
/* 313 */         String relamName = conf.substring(fromLoc + 4).trim();
/*     */         
/* 315 */         curRealm.importFrom(relamName, importSpec);
/*     */         continue;
/*     */       } 
/* 318 */       if (line.startsWith("load")) {
/*     */         
/* 320 */         String constituent = line.substring("load".length()).trim();
/*     */         
/* 322 */         constituent = filter(constituent);
/*     */         
/* 324 */         if (constituent.indexOf("*") >= 0) {
/*     */           
/* 326 */           loadGlob(constituent, curRealm);
/*     */           
/*     */           continue;
/*     */         } 
/* 330 */         File file = new File(constituent);
/*     */         
/* 332 */         if (file.exists()) {
/*     */           
/* 334 */           curRealm.addConstituent(file.toURL());
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/*     */         try {
/* 340 */           curRealm.addConstituent(new URL(constituent));
/*     */         }
/* 342 */         catch (MalformedURLException e) {
/*     */           
/* 344 */           throw new FileNotFoundException(constituent);
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 349 */       if (line.startsWith("optionally")) {
/*     */         
/* 351 */         String constituent = line.substring("optionally".length()).trim();
/*     */         
/* 353 */         constituent = filter(constituent);
/*     */         
/* 355 */         if (constituent.indexOf("*") >= 0) {
/*     */           
/* 357 */           loadGlob(constituent, curRealm, true);
/*     */           
/*     */           continue;
/*     */         } 
/* 361 */         File file = new File(constituent);
/*     */         
/* 363 */         if (file.exists()) {
/*     */           
/* 365 */           curRealm.addConstituent(file.toURL());
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/*     */         try {
/* 371 */           curRealm.addConstituent(new URL(constituent));
/*     */         }
/* 373 */         catch (MalformedURLException e) {}
/*     */ 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 382 */       throw new ConfigurationException("Unhandled configuration", lineNo, line);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 387 */     associateRealms();
/*     */     
/* 389 */     if (this.launcher != null) this.launcher.setWorld(this.world);
/*     */     
/* 391 */     reader.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void associateRealms() {
/* 399 */     List sortRealmNames = new ArrayList(this.configuredRealms.keySet());
/*     */ 
/*     */     
/* 402 */     Comparator comparator = new Comparator(this) {
/*     */         private final Configurator this$0;
/*     */         
/*     */         public int compare(Object o1, Object o2) {
/* 406 */           String g1 = (String)o1;
/* 407 */           String g2 = (String)o2;
/* 408 */           return g1.compareTo(g2);
/*     */         }
/*     */       };
/*     */     
/* 412 */     Collections.sort(sortRealmNames, comparator);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 424 */     for (Iterator i = sortRealmNames.iterator(); i.hasNext(); ) {
/*     */       
/* 426 */       String realmName = (String)i.next();
/*     */       
/* 428 */       int j = realmName.lastIndexOf('.');
/*     */       
/* 430 */       if (j > 0) {
/*     */         
/* 432 */         String parentRealmName = realmName.substring(0, j);
/*     */         
/* 434 */         ClassRealm parentRealm = (ClassRealm)this.configuredRealms.get(parentRealmName);
/*     */         
/* 436 */         if (parentRealm != null) {
/*     */           
/* 438 */           ClassRealm realm = (ClassRealm)this.configuredRealms.get(realmName);
/*     */           
/* 440 */           realm.setParent(parentRealm);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void loadGlob(String line, ClassRealm realm) throws MalformedURLException, FileNotFoundException {
/* 459 */     loadGlob(line, realm, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void loadGlob(String line, ClassRealm realm, boolean optionally) throws MalformedURLException, FileNotFoundException {
/* 476 */     File globFile = new File(line);
/*     */     
/* 478 */     File dir = globFile.getParentFile();
/* 479 */     if (!dir.exists()) {
/*     */       
/* 481 */       if (optionally) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 487 */       throw new FileNotFoundException(dir.toString());
/*     */     } 
/*     */ 
/*     */     
/* 491 */     String localName = globFile.getName();
/*     */     
/* 493 */     int starLoc = localName.indexOf("*");
/*     */     
/* 495 */     String prefix = localName.substring(0, starLoc);
/*     */     
/* 497 */     String suffix = localName.substring(starLoc + 1);
/*     */     
/* 499 */     File[] matches = dir.listFiles(new FilenameFilter(this, prefix, suffix) {
/*     */           private final String val$prefix;
/*     */           
/*     */           public boolean accept(File dir, String name) {
/* 503 */             if (!name.startsWith(this.val$prefix))
/*     */             {
/* 505 */               return false;
/*     */             }
/*     */             
/* 508 */             if (!name.endsWith(this.val$suffix))
/*     */             {
/* 510 */               return false;
/*     */             }
/*     */             
/* 513 */             return true;
/*     */           }
/*     */           private final String val$suffix; private final Configurator this$0;
/*     */         });
/* 517 */     for (int i = 0; i < matches.length; i++)
/*     */     {
/* 519 */       realm.addConstituent(matches[i].toURL());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String filter(String text) throws ConfigurationException {
/* 534 */     String result = "";
/*     */     
/* 536 */     int cur = 0;
/* 537 */     int textLen = text.length();
/*     */     
/* 539 */     int propStart = -1;
/* 540 */     int propStop = -1;
/*     */     
/* 542 */     String propName = null;
/* 543 */     String propValue = null;
/*     */     
/* 545 */     while (cur < textLen) {
/*     */       
/* 547 */       propStart = text.indexOf("${", cur);
/*     */       
/* 549 */       if (propStart < 0) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/* 554 */       result = result + text.substring(cur, propStart);
/*     */       
/* 556 */       propStop = text.indexOf("}", propStart);
/*     */       
/* 558 */       if (propStop < 0)
/*     */       {
/* 560 */         throw new ConfigurationException("Unterminated property: " + text.substring(propStart));
/*     */       }
/*     */       
/* 563 */       propName = text.substring(propStart + 2, propStop);
/*     */       
/* 565 */       propValue = System.getProperty(propName);
/*     */       
/* 567 */       if (propValue == null)
/*     */       {
/* 569 */         throw new ConfigurationException("No such property: " + propName);
/*     */       }
/* 571 */       result = result + propValue;
/*     */       
/* 573 */       cur = propStop + 1;
/*     */     } 
/*     */     
/* 576 */     result = result + text.substring(cur);
/*     */     
/* 578 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean canIgnore(String line) {
/* 591 */     return (line.length() == 0 || line.startsWith("#"));
/*     */   }
/*     */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworlds\Configurator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */