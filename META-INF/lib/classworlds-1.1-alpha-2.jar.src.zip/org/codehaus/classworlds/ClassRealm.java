package org.codehaus.classworlds;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;

public interface ClassRealm {
  String getId();
  
  ClassWorld getWorld();
  
  void importFrom(String paramString1, String paramString2) throws NoSuchRealmException;
  
  void addConstituent(URL paramURL);
  
  ClassRealm locateSourceRealm(String paramString);
  
  void setParent(ClassRealm paramClassRealm);
  
  ClassRealm createChildRealm(String paramString) throws DuplicateRealmException;
  
  ClassLoader getClassLoader();
  
  ClassRealm getParent();
  
  URL[] getConstituents();
  
  Class loadClass(String paramString) throws ClassNotFoundException;
  
  URL getResource(String paramString);
  
  Enumeration findResources(String paramString) throws IOException;
  
  InputStream getResourceAsStream(String paramString);
  
  void display();
}


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworlds\ClassRealm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */