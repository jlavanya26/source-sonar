/*    */ package org.codehaus.classworlds;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.net.URLStreamHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BytesURLStreamHandler
/*    */   extends URLStreamHandler
/*    */ {
/*    */   byte[] content;
/*    */   int offset;
/*    */   int length;
/*    */   
/*    */   public BytesURLStreamHandler(byte[] content) {
/* 22 */     this.content = content;
/*    */   }
/*    */ 
/*    */   
/*    */   public URLConnection openConnection(URL url) {
/* 27 */     return new BytesURLConnection(url, this.content);
/*    */   }
/*    */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworlds\BytesURLStreamHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */