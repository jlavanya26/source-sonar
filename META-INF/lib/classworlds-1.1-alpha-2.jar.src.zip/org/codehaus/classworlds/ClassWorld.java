/*     */ package org.codehaus.classworlds;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassWorld
/*     */ {
/*     */   public ClassWorld(String realmId, ClassLoader classLoader) {
/*  65 */     this();
/*     */ 
/*     */     
/*     */     try {
/*  69 */       newRealm(realmId, classLoader);
/*     */     }
/*  71 */     catch (DuplicateRealmException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   private Map realms = new HashMap();
/*     */ 
/*     */   
/*     */   public ClassWorld() {}
/*     */   
/*     */   public ClassRealm newRealm(String id) throws DuplicateRealmException {
/*  85 */     return newRealm(id, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassRealm newRealm(String id, ClassLoader classLoader) throws DuplicateRealmException {
/*  91 */     if (this.realms.containsKey(id))
/*     */     {
/*  93 */       throw new DuplicateRealmException(this, id);
/*     */     }
/*     */     
/*  96 */     ClassRealm realm = null;
/*     */     
/*  98 */     if (classLoader != null) {
/*     */       
/* 100 */       realm = new DefaultClassRealm(this, id, classLoader);
/*     */       
/* 102 */       this.realms.put(id, realm);
/*     */     }
/*     */     else {
/*     */       
/* 106 */       realm = new DefaultClassRealm(this, id);
/*     */     } 
/*     */     
/* 109 */     this.realms.put(id, realm);
/*     */     
/* 111 */     return realm;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void disposeRealm(String id) throws NoSuchRealmException {
/* 117 */     this.realms.remove(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassRealm getRealm(String id) throws NoSuchRealmException {
/* 123 */     if (this.realms.containsKey(id))
/*     */     {
/* 125 */       return (ClassRealm)this.realms.get(id);
/*     */     }
/*     */     
/* 128 */     throw new NoSuchRealmException(this, id);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection getRealms() {
/* 133 */     return this.realms.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class loadClass(String name) throws ClassNotFoundException {
/* 142 */     return getClass().getClassLoader().loadClass(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworlds\ClassWorld.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */