/*     */ package org.codehaus.classworlds;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Launcher
/*     */ {
/*     */   protected static final String CLASSWORLDS_CONF = "classworlds.conf";
/*     */   protected static final String UBERJAR_CONF_DIR = "WORLDS-INF/conf/";
/*     */   protected ClassLoader systemClassLoader;
/*     */   protected String mainClassName;
/*     */   protected String mainRealmName;
/*     */   protected ClassWorld world;
/*  90 */   private int exitCode = 0;
/*     */ 
/*     */   
/*     */   static Class array$Ljava$lang$String;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSystemClassLoader(ClassLoader loader) {
/*  98 */     this.systemClassLoader = loader;
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassLoader getSystemClassLoader() {
/* 103 */     return this.systemClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getExitCode() {
/* 108 */     return this.exitCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAppMain(String mainClassName, String mainRealmName) {
/* 113 */     this.mainClassName = mainClassName;
/*     */     
/* 115 */     this.mainRealmName = mainRealmName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMainRealmName() {
/* 120 */     return this.mainRealmName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMainClassName() {
/* 125 */     return this.mainClassName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWorld(ClassWorld world) {
/* 130 */     this.world = world;
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassWorld getWorld() {
/* 135 */     return this.world;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(InputStream is) throws IOException, MalformedURLException, ConfigurationException, DuplicateRealmException, NoSuchRealmException {
/* 154 */     Configurator configurator = new Configurator(this);
/*     */     
/* 156 */     configurator.configure(is);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getMainClass() throws ClassNotFoundException, NoSuchRealmException {
/* 169 */     return getMainRealm().loadClass(getMainClassName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassRealm getMainRealm() throws NoSuchRealmException {
/* 181 */     return getWorld().getRealm(getMainRealmName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method getEnhancedMainMethod() throws ClassNotFoundException, NoSuchMethodException, NoSuchRealmException {
/* 195 */     Method[] methods = getMainClass().getMethods();
/* 196 */     Class cwClass = getMainRealm().loadClass(ClassWorld.class.getName());
/*     */     
/* 198 */     Method m = getMainClass().getMethod("main", new Class[] { (array$Ljava$lang$String == null) ? (array$Ljava$lang$String = class$("[Ljava.lang.String;")) : array$Ljava$lang$String, cwClass });
/*     */     
/* 200 */     int modifiers = m.getModifiers();
/*     */     
/* 202 */     if (Modifier.isStatic(modifiers) && Modifier.isPublic(modifiers))
/*     */     {
/* 204 */       if (m.getReturnType() == int.class || m.getReturnType() == void.class)
/*     */       {
/* 206 */         return m;
/*     */       }
/*     */     }
/*     */     
/* 210 */     throw new NoSuchMethodException("public static void main(String[] args, ClassWorld world)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method getMainMethod() throws ClassNotFoundException, NoSuchMethodException, NoSuchRealmException {
/* 224 */     Method m = getMainClass().getMethod("main", new Class[] { (array$Ljava$lang$String == null) ? (array$Ljava$lang$String = class$("[Ljava.lang.String;")) : array$Ljava$lang$String });
/*     */     
/* 226 */     int modifiers = m.getModifiers();
/*     */     
/* 228 */     if (Modifier.isStatic(modifiers) && Modifier.isPublic(modifiers))
/*     */     {
/* 230 */       if (m.getReturnType() == int.class || m.getReturnType() == void.class)
/*     */       {
/* 232 */         return m;
/*     */       }
/*     */     }
/*     */     
/* 236 */     throw new NoSuchMethodException("public static void main(String[] args) in " + getMainClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void launch(String[] args) throws ClassNotFoundException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, NoSuchRealmException {
/*     */     try {
/* 255 */       launchEnhanced(args);
/*     */ 
/*     */       
/*     */       return;
/* 259 */     } catch (NoSuchMethodException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 264 */       launchStandard(args);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void launchEnhanced(String[] args) throws ClassNotFoundException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, NoSuchRealmException {
/* 290 */     ClassRealm mainRealm = getMainRealm();
/*     */     
/* 292 */     Class mainClass = getMainClass();
/*     */     
/* 294 */     Method mainMethod = getEnhancedMainMethod();
/*     */     
/* 296 */     ClassLoader cl = mainRealm.getClassLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     Thread.currentThread().setContextClassLoader(cl);
/*     */     
/* 315 */     Object ret = mainMethod.invoke(mainClass, new Object[] { args, getWorld() });
/* 316 */     if (ret instanceof Integer)
/*     */     {
/* 318 */       this.exitCode = ((Integer)ret).intValue();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void launchStandard(String[] args) throws ClassNotFoundException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, NoSuchRealmException {
/* 345 */     ClassRealm mainRealm = getMainRealm();
/*     */     
/* 347 */     Class mainClass = getMainClass();
/*     */     
/* 349 */     Method mainMethod = getMainMethod();
/*     */     
/* 351 */     Thread.currentThread().setContextClassLoader(mainRealm.getClassLoader());
/*     */     
/* 353 */     Object ret = mainMethod.invoke(mainClass, new Object[] { args });
/* 354 */     if (ret instanceof Integer)
/*     */     {
/* 356 */       this.exitCode = ((Integer)ret).intValue();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/* 375 */       int exitCode = mainWithExitCode(args);
/* 376 */       System.exit(exitCode);
/*     */     }
/* 378 */     catch (Exception e) {
/*     */       
/* 380 */       e.printStackTrace();
/* 381 */       System.exit(100);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int mainWithExitCode(String[] args) throws Exception {
/* 395 */     String classworldsConf = System.getProperty("classworlds.conf");
/*     */     
/* 397 */     InputStream is = null;
/*     */     
/* 399 */     Launcher launcher = new Launcher();
/*     */     
/* 401 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*     */     
/* 403 */     launcher.setSystemClassLoader(cl);
/*     */     
/* 405 */     if (classworldsConf != null) {
/*     */       
/* 407 */       is = new FileInputStream(classworldsConf);
/*     */ 
/*     */     
/*     */     }
/* 411 */     else if ("true".equals(System.getProperty("classworlds.bootstrapped"))) {
/*     */       
/* 413 */       is = cl.getResourceAsStream("WORLDS-INF/conf/classworlds.conf");
/*     */     }
/*     */     else {
/*     */       
/* 417 */       is = cl.getResourceAsStream("classworlds.conf");
/*     */     } 
/*     */ 
/*     */     
/* 421 */     if (is == null)
/*     */     {
/* 423 */       throw new Exception("classworlds configuration not specified nor found in the classpath");
/*     */     }
/*     */     
/* 426 */     launcher.configure(is);
/*     */ 
/*     */     
/*     */     try {
/* 430 */       launcher.launch(args);
/*     */     }
/* 432 */     catch (InvocationTargetException e) {
/*     */       
/* 434 */       ClassRealm realm = launcher.getWorld().getRealm(launcher.getMainRealmName());
/*     */       
/* 436 */       URL[] constituents = realm.getConstituents();
/*     */       
/* 438 */       System.out.println("---------------------------------------------------");
/*     */       
/* 440 */       for (int i = 0; i < constituents.length; i++)
/*     */       {
/* 442 */         System.out.println("constituent[" + i + "]: " + constituents[i]);
/*     */       }
/*     */       
/* 445 */       System.out.println("---------------------------------------------------");
/*     */ 
/*     */       
/* 448 */       Throwable t = e.getTargetException();
/*     */       
/* 450 */       if (t instanceof Exception)
/*     */       {
/* 452 */         throw (Exception)t;
/*     */       }
/* 454 */       if (t instanceof Error)
/*     */       {
/* 456 */         throw (Error)t;
/*     */       }
/*     */ 
/*     */       
/* 460 */       throw e;
/*     */     } 
/*     */     
/* 463 */     return launcher.getExitCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworlds\Launcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */