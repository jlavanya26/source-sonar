/*    */ package org.codehaus.classworlds;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UrlUtils
/*    */ {
/*    */   public static String normalizeUrlPath(String name) {
/* 11 */     if (name.startsWith("/"))
/*    */     {
/* 13 */       name = name.substring(1);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 20 */     int i = name.indexOf("/..");
/*    */ 
/*    */ 
/*    */     
/* 24 */     if (i > 0) {
/*    */       
/* 26 */       int j = name.lastIndexOf("/", i - 1);
/*    */       
/* 28 */       name = name.substring(0, j) + name.substring(i + 3);
/*    */     } 
/*    */     
/* 31 */     return name;
/*    */   }
/*    */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworlds\UrlUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */