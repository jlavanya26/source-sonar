/*     */ package org.codehaus.classworlds;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmbeddedLauncher
/*     */   extends Launcher
/*     */ {
/*  76 */   private static String LAUNCH_METHOD = "execute";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class array$Ljava$lang$String;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAppMain(String mainClassName, String mainRealmName) {
/*  96 */     this.mainClassName = mainClassName;
/*  97 */     this.mainRealmName = mainRealmName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMainRealmName() {
/* 107 */     return this.mainRealmName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMainClassName() {
/* 117 */     return this.mainClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getMainClass() throws ClassNotFoundException, NoSuchRealmException {
/* 130 */     return getMainRealm().loadClass(getMainClassName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassRealm getMainRealm() throws NoSuchRealmException {
/* 142 */     return getWorld().getRealm(getMainRealmName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method getEnhancedMainMethod() throws ClassNotFoundException, NoSuchMethodException, NoSuchRealmException {
/* 156 */     Method[] methods = getMainClass().getMethods();
/*     */     
/* 158 */     for (int i = 0; i < methods.length; i++) {
/*     */       
/* 160 */       Method method = methods[i];
/*     */       
/* 162 */       if (LAUNCH_METHOD.equals(method.getName())) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 167 */         int modifiers = method.getModifiers();
/*     */         
/* 169 */         if (Modifier.isPublic(modifiers))
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 174 */           if (method.getReturnType() == void.class) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 179 */             Class[] paramTypes = method.getParameterTypes();
/*     */             
/* 181 */             if (paramTypes.length == 2)
/*     */             {
/*     */ 
/*     */ 
/*     */               
/* 186 */               if (paramTypes[0] == ((array$Ljava$lang$String == null) ? (array$Ljava$lang$String = class$("[Ljava.lang.String;")) : array$Ljava$lang$String))
/*     */               {
/*     */ 
/*     */ 
/*     */                 
/* 191 */                 if (paramTypes[1] == ClassWorld.class)
/*     */                 {
/*     */ 
/*     */ 
/*     */                   
/* 196 */                   return method; }  }  } 
/*     */           }  } 
/*     */       } 
/* 199 */     }  throw new NoSuchMethodException("public void execute(ClassWorld world)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void launchX() throws ClassNotFoundException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, NoSuchRealmException {
/* 225 */     ClassRealm mainRealm = getMainRealm();
/* 226 */     Class mainClass = getMainClass();
/* 227 */     Method mainMethod = getEnhancedMainMethod();
/*     */     
/* 229 */     Thread.currentThread().setContextClassLoader(mainRealm.getClassLoader());
/*     */     
/* 231 */     mainMethod.invoke(mainClass, new Object[] { getWorld() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void launch() throws Exception {
/* 241 */     String classworldsConf = System.getProperty("classworlds.conf");
/*     */     
/* 243 */     InputStream is = null;
/*     */     
/* 245 */     if (classworldsConf != null) {
/*     */       
/* 247 */       is = new FileInputStream(classworldsConf);
/*     */     }
/*     */     else {
/*     */       
/* 251 */       ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*     */       
/* 253 */       if ("true".equals(System.getProperty("classworlds.bootstrapped"))) {
/*     */         
/* 255 */         is = cl.getResourceAsStream("WORLDS-INF/conf/classworlds.conf");
/*     */       }
/*     */       else {
/*     */         
/* 259 */         is = cl.getResourceAsStream("classworlds.conf");
/*     */       } 
/*     */     } 
/*     */     
/* 263 */     if (is == null)
/*     */     {
/* 265 */       throw new Exception("classworlds configuration not specified nor found in the classpath");
/*     */     }
/*     */ 
/*     */     
/* 269 */     configure(is);
/*     */ 
/*     */     
/*     */     try {
/* 273 */       launchX();
/*     */     }
/* 275 */     catch (InvocationTargetException e) {
/*     */ 
/*     */       
/* 278 */       Throwable t = e.getTargetException();
/* 279 */       if (t instanceof Exception)
/*     */       {
/* 281 */         throw (Exception)t;
/*     */       }
/* 283 */       if (t instanceof Error)
/*     */       {
/* 285 */         throw (Error)t;
/*     */       }
/*     */ 
/*     */       
/* 289 */       throw e;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworlds\EmbeddedLauncher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */