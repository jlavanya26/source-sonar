/*     */ package org.codehaus.classworlds;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UberJarRealmClassLoader
/*     */   extends RealmClassLoader
/*     */ {
/*     */   private Map classIndex;
/*     */   private List urls;
/*     */   private Map jarIndexes;
/*     */   
/*     */   public UberJarRealmClassLoader(DefaultClassRealm realm) {
/*  83 */     super(realm);
/*     */     
/*  85 */     this.urls = new ArrayList();
/*     */     
/*  87 */     this.classIndex = new HashMap();
/*     */     
/*  89 */     this.jarIndexes = new HashMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addConstituent(URL constituent) {
/*  95 */     if ("jar".equals(constituent.getProtocol()) || constituent.toExternalForm().endsWith(".jar"))
/*     */     {
/*  97 */       buildIndexForJar(constituent);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 102 */     this.urls.add(constituent);
/*     */     
/* 104 */     super.addConstituent(constituent);
/*     */   }
/*     */ 
/*     */   
/*     */   private void buildIndexForJar(URL inUrl) {
/* 109 */     HashMap index = new HashMap();
/*     */     
/* 111 */     String urlText = null;
/*     */     
/* 113 */     if (inUrl.getProtocol().equals("jar")) {
/*     */       
/* 115 */       urlText = inUrl.toExternalForm();
/*     */     }
/*     */     else {
/*     */       
/* 119 */       urlText = "jar:" + inUrl.toExternalForm();
/*     */     } 
/*     */ 
/*     */     
/* 123 */     URL resourceUrl = null;
/*     */ 
/*     */     
/*     */     try {
/* 127 */       JarInputStream in = new JarInputStream(inUrl.openStream());
/*     */ 
/*     */       
/*     */       try {
/* 131 */         JarEntry entry = null;
/*     */         
/* 133 */         while ((entry = in.getNextJarEntry()) != null)
/*     */         {
/* 135 */           String resourceName = entry.getName();
/*     */           
/* 137 */           resourceUrl = new URL(urlText + "!/" + resourceName);
/*     */           
/* 139 */           index.put(resourceName, resourceUrl);
/*     */         }
/*     */       
/*     */       } finally {
/*     */         
/* 144 */         in.close();
/*     */       }
/*     */     
/* 147 */     } catch (IOException e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     this.jarIndexes.put(inUrl, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class loadClassDirect(String className) throws ClassNotFoundException {
/* 166 */     String classPath = className.replace('.', '/') + ".class";
/*     */     
/* 168 */     if (this.classIndex.containsKey(classPath))
/*     */     {
/* 170 */       return (Class)this.classIndex.get(classPath);
/*     */     }
/*     */     
/* 173 */     Iterator urlIter = this.urls.iterator();
/* 174 */     URL eachUrl = null;
/*     */     
/* 176 */     byte[] classBytes = null;
/*     */     
/* 178 */     while (classBytes == null && urlIter.hasNext()) {
/*     */       
/* 180 */       eachUrl = urlIter.next();
/*     */       
/* 182 */       if ("jar".equals(eachUrl.getProtocol()) || eachUrl.toExternalForm().endsWith(".jar")) {
/*     */         
/* 184 */         classBytes = findClassInJarStream(eachUrl, classPath);
/*     */         
/*     */         continue;
/*     */       } 
/* 188 */       classBytes = findClassInDirectoryUrl(eachUrl, classPath);
/*     */     } 
/*     */ 
/*     */     
/* 192 */     if (classBytes == null)
/*     */     {
/*     */       
/* 195 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 199 */     Class cls = defineClass(className, classBytes, 0, classBytes.length);
/*     */     
/* 201 */     this.classIndex.put(classPath, cls);
/*     */     
/* 203 */     return cls;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public URL findResource(String name) {
/* 209 */     URL resourceUrl = null;
/*     */     
/* 211 */     Iterator urlIter = this.urls.iterator();
/*     */     
/* 213 */     URL eachUrl = null;
/*     */     
/* 215 */     while (urlIter.hasNext()) {
/*     */       
/* 217 */       eachUrl = urlIter.next();
/*     */       
/* 219 */       if ("jar".equals(eachUrl.getProtocol()) || eachUrl.toExternalForm().endsWith(".jar")) {
/*     */         
/* 221 */         resourceUrl = findResourceInJarStream(eachUrl, name);
/*     */       }
/*     */       else {
/*     */         
/* 225 */         resourceUrl = findResourceInDirectoryUrl(eachUrl, name);
/*     */       } 
/*     */       
/* 228 */       if (resourceUrl != null)
/*     */       {
/* 230 */         return resourceUrl;
/*     */       }
/*     */     } 
/*     */     
/* 234 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration findResourcesDirect(String name) {
/* 239 */     Vector list = new Vector();
/*     */     
/* 241 */     URL resourceUrl = null;
/*     */     
/* 243 */     Iterator urlIter = this.urls.iterator();
/*     */     
/* 245 */     URL eachUrl = null;
/*     */     
/* 247 */     while (urlIter.hasNext()) {
/*     */       
/* 249 */       eachUrl = urlIter.next();
/*     */       
/* 251 */       if ("jar".equals(eachUrl.getProtocol()) || eachUrl.toExternalForm().endsWith(".jar")) {
/*     */         
/* 253 */         resourceUrl = findResourceInJarStream(eachUrl, name);
/*     */       }
/*     */       else {
/*     */         
/* 257 */         resourceUrl = findResourceInDirectoryUrl(eachUrl, name);
/*     */       } 
/*     */       
/* 260 */       if (resourceUrl != null)
/*     */       {
/* 262 */         list.add(resourceUrl);
/*     */       }
/*     */     } 
/*     */     
/* 266 */     return list.elements();
/*     */   }
/*     */ 
/*     */   
/*     */   protected URL findResourceInJarStream(URL inUrl, String path) {
/* 271 */     return (URL)((Map)this.jarIndexes.get(inUrl)).get(path);
/*     */   }
/*     */ 
/*     */   
/*     */   protected URL findResourceInDirectoryUrl(URL inUrl, String path) {
/* 276 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected byte[] findClassInJarStream(URL inUrl, String path) {
/* 281 */     URL classUrl = (URL)((Map)this.jarIndexes.get(inUrl)).get(path);
/*     */     
/* 283 */     if (classUrl != null) {
/*     */       
/*     */       try {
/*     */         
/* 287 */         return readStream(classUrl.openStream());
/*     */       }
/* 289 */       catch (IOException e) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 295 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] findClassInDirectoryUrl(URL url, String path) {
/*     */     try {
/* 302 */       URL classUrl = new URL(url, path);
/*     */     }
/* 304 */     catch (IOException e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private byte[] readStream(InputStream in) throws IOException {
/* 314 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*     */ 
/*     */     
/*     */     try {
/* 318 */       byte[] buffer = new byte[2048];
/*     */       
/* 320 */       int read = 0;
/*     */       
/* 322 */       while (in.available() > 0) {
/*     */         
/* 324 */         read = in.read(buffer, 0, buffer.length);
/*     */         
/* 326 */         if (read < 0) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 331 */         out.write(buffer, 0, read);
/*     */       } 
/*     */       
/* 334 */       return out.toByteArray();
/*     */     }
/*     */     finally {
/*     */       
/* 338 */       out.close();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworlds\UberJarRealmClassLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */