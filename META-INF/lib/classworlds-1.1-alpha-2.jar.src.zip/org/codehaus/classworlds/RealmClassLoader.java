/*     */ package org.codehaus.classworlds;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RealmClassLoader
/*     */   extends URLClassLoader
/*     */ {
/*     */   protected DefaultClassRealm realm;
/*     */   
/*     */   RealmClassLoader(DefaultClassRealm realm) {
/*  83 */     this(realm, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RealmClassLoader(DefaultClassRealm realm, ClassLoader classLoader) {
/*  94 */     super(new URL[0], classLoader);
/*  95 */     this.realm = realm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultClassRealm getRealm() {
/* 108 */     return this.realm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addConstituent(URL constituent) {
/* 122 */     String urlStr = constituent.toExternalForm();
/* 123 */     if (!urlStr.endsWith(".class")) {
/*     */       
/* 125 */       if (urlStr.startsWith("jar:") && urlStr.endsWith("!/")) {
/*     */ 
/*     */ 
/*     */         
/* 129 */         urlStr = urlStr.substring(4, urlStr.length() - 2);
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 134 */           constituent = new URL(urlStr);
/*     */         }
/* 136 */         catch (MalformedURLException e) {
/*     */           
/* 138 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */       
/* 142 */       addURL(constituent);
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 148 */         byte[] b = getBytesToEndOfStream(new DataInputStream(constituent.openStream()));
/* 149 */         int start = urlStr.lastIndexOf("byteclass") + 10;
/* 150 */         int end = urlStr.lastIndexOf(".class");
/*     */         
/* 152 */         String className = urlStr.substring(start, end);
/*     */         
/* 154 */         defineClass(className, b, 0, b.length);
/*     */         
/* 156 */         addURL(constituent);
/*     */       }
/* 158 */       catch (IOException e) {
/*     */         
/* 160 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytesToEndOfStream(DataInputStream in) throws IOException {
/* 172 */     int chunkSize = (in.available() > 0) ? in.available() : 2048;
/* 173 */     byte[] buf = new byte[chunkSize];
/* 174 */     ByteArrayOutputStream byteStream = new ByteArrayOutputStream(chunkSize);
/*     */     
/*     */     int count;
/* 177 */     while ((count = in.read(buf)) != -1)
/*     */     {
/* 179 */       byteStream.write(buf, 0, count);
/*     */     }
/* 181 */     return byteStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class loadClassDirect(String name) throws ClassNotFoundException {
/* 195 */     return super.loadClass(name, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class loadClass(String name, boolean resolve) throws ClassNotFoundException {
/* 214 */     return getRealm().loadClass(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL[] getURLs() {
/* 223 */     return super.getURLs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL findResource(String name) {
/* 232 */     return super.findResource(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getResource(String name) {
/* 237 */     return getRealm().getResource(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getResourceDirect(String name) {
/* 247 */     return super.getResource(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration findResources(String name) throws IOException {
/* 252 */     return getRealm().findResources(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration findResourcesDirect(String name) throws IOException {
/* 263 */     return super.findResources(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworlds\RealmClassLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */