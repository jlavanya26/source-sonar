/*     */ package org.codehaus.classworlds.uberjar.protocol.jar;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.JarInputStream;
/*     */ import org.codehaus.classworlds.UrlUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarUrlConnection
/*     */   extends JarURLConnection
/*     */ {
/*     */   private URL baseResource;
/*     */   private String[] segments;
/*     */   private InputStream in;
/*     */   
/*     */   JarUrlConnection(URL url) throws IOException {
/* 106 */     super(url = normaliseURL(url));
/*     */     
/* 108 */     String baseText = url.getPath();
/*     */     
/* 110 */     int bangLoc = baseText.indexOf("!");
/*     */     
/* 112 */     String baseResourceText = baseText.substring(0, bangLoc);
/*     */     
/* 114 */     String extraText = "";
/*     */     
/* 116 */     if (bangLoc <= baseText.length() - 2 && baseText.charAt(bangLoc + 1) == '/') {
/*     */ 
/*     */ 
/*     */       
/* 120 */       if (bangLoc + 2 == baseText.length())
/*     */       {
/* 122 */         extraText = "";
/*     */       }
/*     */       else
/*     */       {
/* 126 */         extraText = baseText.substring(bangLoc + 1);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 131 */       throw new MalformedURLException("No !/ in url: " + url.toExternalForm());
/*     */     } 
/*     */ 
/*     */     
/* 135 */     List segments = new ArrayList();
/*     */     
/* 137 */     StringTokenizer tokens = new StringTokenizer(extraText, "!");
/*     */     
/* 139 */     while (tokens.hasMoreTokens())
/*     */     {
/* 141 */       segments.add(tokens.nextToken());
/*     */     }
/*     */     
/* 144 */     this.segments = segments.<String>toArray(new String[segments.size()]);
/*     */     
/* 146 */     this.baseResource = new URL(baseResourceText);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static URL normaliseURL(URL url) throws MalformedURLException {
/* 151 */     String text = UrlUtils.normalizeUrlPath(url.toString());
/*     */     
/* 153 */     if (!text.startsWith("jar:"))
/*     */     {
/* 155 */       text = "jar:" + text;
/*     */     }
/*     */     
/* 158 */     if (text.indexOf('!') < 0)
/*     */     {
/* 160 */       text = text + "!/";
/*     */     }
/*     */     
/* 163 */     return new URL(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getSegments() {
/* 177 */     return this.segments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected URL getBaseResource() {
/* 187 */     return this.baseResource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/* 196 */     if (this.segments.length == 0) {
/*     */       
/* 198 */       setupBaseResourceInputStream();
/*     */     }
/*     */     else {
/*     */       
/* 202 */       setupPathedInputStream();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setupBaseResourceInputStream() throws IOException {
/* 214 */     this.in = getBaseResource().openStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setupPathedInputStream() throws IOException {
/* 225 */     InputStream curIn = getBaseResource().openStream();
/*     */     
/* 227 */     for (int i = 0; i < this.segments.length; i++)
/*     */     {
/* 229 */       curIn = getSegmentInputStream(curIn, this.segments[i]);
/*     */     }
/*     */ 
/*     */     
/* 233 */     this.in = curIn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream getSegmentInputStream(InputStream baseIn, String segment) throws IOException {
/* 249 */     JarInputStream jarIn = new JarInputStream(baseIn);
/* 250 */     JarEntry entry = null;
/*     */     
/* 252 */     while (jarIn.available() != 0) {
/*     */       
/* 254 */       entry = jarIn.getNextJarEntry();
/*     */       
/* 256 */       if (entry == null) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/* 261 */       if (("/" + entry.getName()).equals(segment))
/*     */       {
/* 263 */         return jarIn;
/*     */       }
/*     */     } 
/*     */     
/* 267 */     throw new IOException("unable to locate segment: " + segment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 276 */     if (this.in == null)
/*     */     {
/* 278 */       connect();
/*     */     }
/* 280 */     return this.in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JarFile getJarFile() throws IOException {
/* 290 */     String url = this.baseResource.toExternalForm();
/*     */     
/* 292 */     if (url.startsWith("file:/"))
/*     */     {
/* 294 */       url = url.substring(6);
/*     */     }
/*     */     
/* 297 */     return new JarFile(URLDecoder.decode(url, "UTF-8"));
/*     */   }
/*     */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworld\\uberjar\protocol\jar\JarUrlConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */