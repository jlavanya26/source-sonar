/*     */ package org.codehaus.classworlds.uberjar.protocol.jar;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Handler
/*     */   extends URLStreamHandler
/*     */ {
/*  70 */   private static final Handler INSTANCE = new Handler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Handler getInstance() {
/*  83 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URLConnection openConnection(URL url) throws IOException {
/* 109 */     return new JarUrlConnection(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseURL(URL url, String spec, int start, int limit) {
/* 120 */     String specPath = spec.substring(start, limit);
/*     */ 
/*     */     
/* 123 */     String urlPath = null;
/*     */     
/* 125 */     if (specPath.charAt(0) == '/') {
/*     */       
/* 127 */       urlPath = specPath;
/*     */     }
/* 129 */     else if (specPath.charAt(0) == '!') {
/*     */       
/* 131 */       String relPath = url.getFile();
/*     */       
/* 133 */       int bangLoc = relPath.lastIndexOf("!");
/*     */       
/* 135 */       if (bangLoc < 0)
/*     */       {
/* 137 */         urlPath = relPath + specPath;
/*     */       }
/*     */       else
/*     */       {
/* 141 */         urlPath = relPath.substring(0, bangLoc) + specPath;
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 147 */       String relPath = url.getFile();
/*     */       
/* 149 */       if (relPath != null) {
/*     */         
/* 151 */         int lastSlashLoc = relPath.lastIndexOf("/");
/*     */         
/* 153 */         if (lastSlashLoc < 0)
/*     */         {
/* 155 */           urlPath = "/" + specPath;
/*     */         }
/*     */         else
/*     */         {
/* 159 */           urlPath = relPath.substring(0, lastSlashLoc + 1) + specPath;
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 165 */         urlPath = specPath;
/*     */       } 
/*     */     } 
/*     */     
/* 169 */     setURL(url, "jar", "", 0, null, null, urlPath, null, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworld\\uberjar\protocol\jar\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */