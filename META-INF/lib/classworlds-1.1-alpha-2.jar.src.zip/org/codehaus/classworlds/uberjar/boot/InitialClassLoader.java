/*     */ package org.codehaus.classworlds.uberjar.boot;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.security.SecureClassLoader;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InitialClassLoader
/*     */   extends SecureClassLoader
/*     */ {
/*  95 */   private Map index = new HashMap();
/*     */   public InitialClassLoader() throws Exception {
/*  97 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*     */     
/*  99 */     URL classUrl = getClass().getResource("InitialClassLoader.class");
/*     */     
/* 101 */     String urlText = classUrl.toExternalForm();
/*     */     
/* 103 */     int bangLoc = urlText.indexOf("!");
/*     */     
/* 105 */     System.setProperty("classworlds.lib", urlText.substring(0, bangLoc) + "!/WORLDS-INF/lib");
/*     */ 
/*     */ 
/*     */     
/* 109 */     this.classworldsJarUrl = new URL(urlText.substring(0, bangLoc) + "!/WORLDS-INF/classworlds.jar");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private URL classworldsJarUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Class findClass(String className) throws ClassNotFoundException {
/* 122 */     String classPath = className.replace('.', '/') + ".class";
/*     */ 
/*     */     
/* 125 */     if (this.index.containsKey(classPath))
/*     */     {
/* 127 */       return (Class)this.index.get(classPath);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 132 */       JarInputStream in = new JarInputStream(this.classworldsJarUrl.openStream());
/*     */ 
/*     */       
/*     */       try {
/* 136 */         JarEntry entry = null;
/*     */         
/* 138 */         while ((entry = in.getNextJarEntry()) != null) {
/*     */           
/* 140 */           if (entry.getName().equals(classPath)) {
/*     */             
/* 142 */             ByteArrayOutputStream out = new ByteArrayOutputStream();
/*     */ 
/*     */             
/*     */             try {
/* 146 */               byte[] buffer = new byte[2048];
/*     */               
/* 148 */               int read = 0;
/*     */               
/* 150 */               while (in.available() > 0) {
/*     */                 
/* 152 */                 read = in.read(buffer, 0, buffer.length);
/*     */ 
/*     */ 
/*     */                 
/* 156 */                 if (read < 0) {
/*     */                   break;
/*     */                 }
/*     */ 
/*     */                 
/* 161 */                 out.write(buffer, 0, read);
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/* 166 */               buffer = out.toByteArray();
/*     */               
/* 168 */               Class cls = defineClass(className, buffer, 0, buffer.length);
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 173 */               this.index.put(className, cls);
/*     */ 
/*     */               
/* 176 */               return cls;
/*     */             }
/*     */             finally {
/*     */               
/* 180 */               out.close();
/*     */             }
/*     */           
/*     */           } 
/*     */         } 
/*     */       } finally {
/*     */         
/* 187 */         in.close();
/*     */       }
/*     */     
/* 190 */     } catch (IOException e) {
/*     */       
/* 192 */       e.printStackTrace();
/* 193 */       throw new ClassNotFoundException("io error reading stream for: " + className);
/*     */     } 
/*     */     
/* 196 */     throw new ClassNotFoundException(className);
/*     */   }
/*     */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworld\\uberjar\boot\InitialClassLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */