/*     */ package org.codehaus.classworlds.uberjar.boot;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Bootstrapper
/*     */ {
/*     */   public static final String LAUNCHER_CLASS_NAME = "org.codehaus.classworlds.Launcher";
/*     */   private String[] args;
/*     */   private InitialClassLoader classLoader;
/*     */   static Class array$Ljava$lang$String;
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 117 */     System.setProperty("java.protocol.handler.pkgs", "org.codehaus.classworlds.uberjar.protocol");
/*     */ 
/*     */     
/* 120 */     Bootstrapper bootstrapper = new Bootstrapper(args);
/*     */     
/* 122 */     bootstrapper.bootstrap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bootstrapper(String[] args) throws Exception {
/* 139 */     this.args = args;
/* 140 */     this.classLoader = new InitialClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassLoader getInitialClassLoader() {
/* 154 */     return this.classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bootstrap() throws Exception {
/* 165 */     ClassLoader cl = getInitialClassLoader();
/*     */     
/* 167 */     Class launcherClass = cl.loadClass("org.codehaus.classworlds.Launcher");
/*     */     
/* 169 */     Method[] methods = launcherClass.getMethods();
/* 170 */     Method mainMethod = null;
/*     */     
/* 172 */     for (int i = 0; i < methods.length; i++) {
/*     */       
/* 174 */       if ("main".equals(methods[i].getName())) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 179 */         int modifiers = methods[i].getModifiers();
/*     */         
/* 181 */         if (Modifier.isStatic(modifiers) && Modifier.isPublic(modifiers))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 188 */           if (methods[i].getReturnType() == void.class) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 193 */             Class[] paramTypes = methods[i].getParameterTypes();
/*     */             
/* 195 */             if (paramTypes.length == 1)
/*     */             {
/*     */ 
/*     */ 
/*     */               
/* 200 */               if (paramTypes[0] == ((array$Ljava$lang$String == null) ? (array$Ljava$lang$String = class$("[Ljava.lang.String;")) : array$Ljava$lang$String)) {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 205 */                 mainMethod = methods[i]; break;
/*     */               }  } 
/*     */           }  } 
/*     */       } 
/* 209 */     }  if (mainMethod == null)
/*     */     {
/* 211 */       throw new NoSuchMethodException("org.codehaus.classworlds.Launcher::main(String[] args)");
/*     */     }
/*     */     
/* 214 */     System.setProperty("classworlds.bootstrapped", "true");
/*     */ 
/*     */     
/* 217 */     mainMethod.invoke(launcherClass, new Object[] { this.args });
/*     */   }
/*     */   
/*     */   static Class class$(String x0) {
/*     */     try {
/*     */       return Class.forName(x0);
/*     */     } catch (ClassNotFoundException x1) {
/*     */       throw new NoClassDefFoundError(x1.getMessage());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworld\\uberjar\boot\Bootstrapper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */