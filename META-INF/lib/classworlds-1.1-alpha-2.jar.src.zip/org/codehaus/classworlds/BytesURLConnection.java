/*    */ package org.codehaus.classworlds;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BytesURLConnection
/*    */   extends URLConnection
/*    */ {
/*    */   protected byte[] content;
/*    */   protected int offset;
/*    */   protected int length;
/*    */   
/*    */   public BytesURLConnection(URL url, byte[] content) {
/* 24 */     super(url);
/* 25 */     this.content = content;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void connect() {}
/*    */ 
/*    */   
/*    */   public InputStream getInputStream() {
/* 34 */     return new ByteArrayInputStream(this.content);
/*    */   }
/*    */ }


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\classworlds-1.1-alpha-2.jar!\org\codehaus\classworlds\BytesURLConnection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */