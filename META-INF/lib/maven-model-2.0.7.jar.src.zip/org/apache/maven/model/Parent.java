/*
 * $Id$
 */

package org.apache.maven.model;

/**
 * 
 *         
 *         The <code>&lt;parent&gt;</code> element contains
 * informations required to the parent project.
 *         
 *       
 * 
 * @version $Revision$ $Date$
 */
public class Parent implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field artifactId
     */
    private String artifactId;

    /**
     * Field groupId
     */
    private String groupId;

    /**
     * Field version
     */
    private String version;

    /**
     * Field relativePath
     */
    private String relativePath = "../pom.xml";


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get 
     *             
     *             The artifact id of the parent project to inherit
     * from.
     *             
     *           
     */
    public String getArtifactId()
    {
        return this.artifactId;
    } //-- String getArtifactId() 

    /**
     * Get 
     *             
     *             The group id of the parent project to inherit
     * from.
     *             
     *           
     */
    public String getGroupId()
    {
        return this.groupId;
    } //-- String getGroupId() 

    /**
     * Get 
     *             
     *             The relative path of the parent
     * <code>pom.xml</code> file within the check out.
     *             The default value is <code>../pom.xml</code>.
     *             Maven looks for the parent pom first in the
     * reactor of currently building projects, then in this
     * location on
     *             the filesystem, then the local repository, and
     * lastly in the remote repo.
     *             <code>relativePath</code> allows you to select a
     * different location,
     *             for example when your structure is flat, or
     * deeper without an intermediate parent pom.
     *             However, the group ID, artifact ID and version
     * are still required,
     *             and must match the file in the location given or
     * it will revert to the repository for the POM.
     *             This feature is only for enhancing the
     * development in a local checkout of that project.
     *             
     *           
     */
    public String getRelativePath()
    {
        return this.relativePath;
    } //-- String getRelativePath() 

    /**
     * Get 
     *             
     *             The version of the parent project to inherit.
     *             
     *           
     */
    public String getVersion()
    {
        return this.version;
    } //-- String getVersion() 

    /**
     * Set 
     *             
     *             The artifact id of the parent project to inherit
     * from.
     *             
     *           
     * 
     * @param artifactId
     */
    public void setArtifactId(String artifactId)
    {
        this.artifactId = artifactId;
    } //-- void setArtifactId(String) 

    /**
     * Set 
     *             
     *             The group id of the parent project to inherit
     * from.
     *             
     *           
     * 
     * @param groupId
     */
    public void setGroupId(String groupId)
    {
        this.groupId = groupId;
    } //-- void setGroupId(String) 

    /**
     * Set 
     *             
     *             The relative path of the parent
     * <code>pom.xml</code> file within the check out.
     *             The default value is <code>../pom.xml</code>.
     *             Maven looks for the parent pom first in the
     * reactor of currently building projects, then in this
     * location on
     *             the filesystem, then the local repository, and
     * lastly in the remote repo.
     *             <code>relativePath</code> allows you to select a
     * different location,
     *             for example when your structure is flat, or
     * deeper without an intermediate parent pom.
     *             However, the group ID, artifact ID and version
     * are still required,
     *             and must match the file in the location given or
     * it will revert to the repository for the POM.
     *             This feature is only for enhancing the
     * development in a local checkout of that project.
     *             
     *           
     * 
     * @param relativePath
     */
    public void setRelativePath(String relativePath)
    {
        this.relativePath = relativePath;
    } //-- void setRelativePath(String) 

    /**
     * Set 
     *             
     *             The version of the parent project to inherit.
     *             
     *           
     * 
     * @param version
     */
    public void setVersion(String version)
    {
        this.version = version;
    } //-- void setVersion(String) 


            
    /**
     * @return the id as <code>groupId:artifactId:version</code>
     */
    public String getId()
    {
        StringBuffer id = new StringBuffer();

        id.append( getGroupId() );
        id.append( ":" );
        id.append( getArtifactId() );
        id.append( ":" );
      //  id.append( getPackaging() );
        id.append( ":" );
        id.append( getVersion() );

        return id.toString();
    }
            
          
    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }}
