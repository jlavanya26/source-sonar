package org.apache.commons.lang.mutable;

public interface Mutable {
  Object getValue();
  
  void setValue(Object paramObject);
}


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\commons-lang-2.6.jar!\org\apache\commons\lang\mutable\Mutable.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */