package org.apache.commons.lang.text;

import java.text.Format;
import java.util.Locale;

public interface FormatFactory {
  Format getFormat(String paramString1, String paramString2, Locale paramLocale);
}


/* Location:              C:\Users\1245817\Downloads\java-custom-rules-1.0-SNAPSHOT\java-custom-rules-1.0-SNAPSHOT.jar!\META-INF\lib\commons-lang-2.6.jar!\org\apache\commons\lang\text\FormatFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */